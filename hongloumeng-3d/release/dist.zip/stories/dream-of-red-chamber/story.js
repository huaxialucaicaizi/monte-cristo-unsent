(function() {
  for (var i = { red: 5905946, wood: 3809812, parch: 16051423, ink: 4853279, jade: 9425328, gold: 14200906, bamboo: 2306847 }, t = { title: "红楼梦 · 三幕", pageTitle: "红楼梦 · 三幕", hook: "走进红楼三幕，你会陪她葬花，还是站在山石后？<br><small>你是翻书的人，能选择怎样看、怎样陪，不能替书中人改命。</small>", startSub: "三幕 · 三个选择 · 三分钟", startButton: "走进荣国府", act1: { hud: "第一幕 · 进府见通灵玉", fade: "一块石头，落进红尘", label: "通灵宝玉", title: "进府见通灵玉", sub: "", text: "<p>荣国府烛火正亮。刚被摔下的玉没有碎，你走到桌前，想给它一个名字。</p>", choices: ["唤它宝玉，挂回他颈上", "唤它顽石，记住它的来处"] }, act2: { hud: "完整版 · 梨香院", fade: "金锁微响，竹影一摇", label: "錾字金锁", title: "金与木", sub: "", text: "<p>金锁上的字恰与玉上的字成对。你选择怎样读这一段缘分？</p>", choices: ["信金玉良缘", "信木石前盟"] }, act3: { hud: "完整版 · 大观园共读", fade: "春日 · 沁芳闸下", label: "落花下的书", title: "共读", sub: "", text: "<p>桃花底下，两个人偷读闲书。你要留下哪一种读法？</p>", choices: ["把书藏进袖中", "把书埋回花下"] }, act4: { hud: "第二幕 · 黛玉葬花", fade: "落花满地，无人收拾", label: "装花的锦囊", title: "黛玉葬花", sub: "", text: "<p>花锄倚在土冢旁，锦囊里装着落花。她低声念诗，你停在山石后。</p>", choices: ["走过去，陪她收拾落花", "留在山石后，听她念完"] }, act5: { hud: "完整版 · 抄检大观园", fade: "秋夜 · 灯笼一盏盏亮起", label: "被翻开的箱笼", title: "抄检", sub: "", text: "<p>箱笼被翻开，所有人的私物摊在灯下。</p>", choices: ["挡在箱笼前替她们求情", "默然看着"] }, act6: { hud: "完整版 · 潇湘馆焚稿", fade: "竹影疏 · 药香冷", label: "一叠诗稿", title: "焚稿", sub: "", text: "<p>她把诗稿一页页递向火盆。</p>", choices: ["让诗稿随旧帕一起成灰", "悄悄留下最后一页"] }, act7: { hud: "第三幕 · 雪夜出家", fade: "雪落无声 · 石归来处", label: "雪地上的大红斗篷", title: "雪夜出家", sub: "", text: "<p>渡口落了雪。红斗篷渐渐远去，一僧一道相随。书要合上了。</p>", choices: ["目送他走远，让雪落满肩", "把这一路刻回石上，再合书"] }, versionTitles: ["玉上留春", "替花留名", "隔山听花", "把泪写下", "顽石惜花", "石上有花", "雪尽归山", "顽石记梦"], endingDescriptions: ["你叫它宝玉，陪她收好落花，最后站在雪里送他走远。", "你珍惜这块玉，也走到花冢前；临别时，把这一捧花刻进石头。", "你把玉挂回他颈上，却始终隔着山石听诗，直到雪里也没有开口。", "花冢前你没有现身，合书前却把听到的句子，一字字刻了下来。", "你知道石头终要回去，还是走过去陪她葬花，再送他走完雪路。", "你唤它顽石，陪她埋好落花，最后把那一日的花冢也刻回石上。", "你记着石头的来处，听过花冢边的哭声，最后没有拦住归去的人。", "你站在故事外听完，又在石上留下字迹，才肯把书合上。"], quotes: ["花开易见落难寻，阶前闷杀葬花人，", "未若锦囊收艳骨，一抔净土掩风流。", "花魂鸟魂总难留，鸟自无言花自羞。", "满纸荒唐言，一把辛酸泪！", "侬今葬花人笑痴，他年葬侬知是谁？", "此系身前身后事，倩谁寄去作神传？", "无材可与补苍天，枉入红尘若许年！", "都云作者痴，谁解其中味？"], combinations: ["AAA", "AAB", "ABA", "ABB", "BAA", "BAB", "BBA", "BBB"], attribution: "改编自《红楼梦》（公版）", author: "@华夏路菜菜子", cardLabels: ["进府见通灵玉", "黛玉葬花", "雪夜出家"], resultTitle: "你的版本", shareButton: "带结局卡发笔记", restartButton: "再走一次", noteTitles: ["我走进了红楼梦的三个房间", "黛玉葬花时，你会走过去吗", "我的红楼三幕，停在这场雪里"], noteBody: `我把《红楼梦》的三个片段做成了能走进去的小工具。
从荣国府的一块玉，走到黛玉的花冢，再到雪里的渡口。走近发光的物件，每幕选一次。
我这次选了「{choice1}」「{choice2}」「{choice3}」，拿到的版本是《{endingTitle}》。
{endingDescription}
八种版本，记下的是不同的读法，不是八个改命结局。你会怎么选？
改编自《红楼梦》（公版）
#小红书小工具 #红楼梦 #互动阅读`, shareUnavailable: "请在小红书 App 的小工具中发布", shareFailed: "发布页暂时无法打开，请稍后再试", fullEntry: "进入七幕完整版" }, u = [
    { type: "text", text: t.act1.title, size: [1.2, 0.8], color: "#4A0E1F", at: [0, 1.9, -3.38] },
    { type: "box", size: [1.6, 0.08, 0.8], color: i.wood, at: [0, 0.78, -1.6], solid: !0 },
    { type: "box", size: [0.5, 0.9, 0.5], color: 4857876, at: [-2.4, 0.45, -2.6], solid: !0 },
    { type: "box", size: [0.5, 0.9, 0.5], color: 4857876, at: [2.4, 0.45, -2.6], solid: !0 },
    { type: "box", size: [1.4, 1.8, 0.08], color: 6957600, at: [-2.6, 0.9, 0.2], solid: !0 },
    { type: "candle", at: [-0.6, 0.82, -1.7], intensity: 2.4 },
    { type: "candle", at: [0.6, 0.82, -1.7], intensity: 2.4 },
    { type: "box", size: [0.24, 0.06, 0.24], color: 2757640, at: [0, 0.85, -1.55] },
    { type: "ico", id: "jade", radius: 0.09, color: i.jade, metalness: 0.3, roughness: 0.25, at: [0, 0.97, -1.55] },
    { type: "light", color: 10479812, intensity: 1.2, distance: 3, at: [0, 1.3, -1.4] }
  ], b = [
    { type: "text", text: t.act2.title, size: [1.2, 0.8], color: "#5a4010", at: [0, 1.9, -3.38] },
    { type: "box", size: [1.2, 0.08, 0.7], color: 4863008, at: [-0.4, 0.78, -1.6], solid: !0 },
    { type: "candle", at: [-0.8, 0.82, -1.7], intensity: 2.2 },
    { type: "box", size: [0.08, 1.4, 0.6], color: 3033642, at: [2.4, 0.7, -1.4], solid: !0 },
    { type: "box", size: [0.1, 2.6, 0.1], color: 4090426, at: [2.6, 1.3, -2.6] },
    { type: "box", size: [0.1, 2.4, 0.1], color: 4090426, at: [2.9, 1.2, -2.2] },
    { type: "cylinder", id: "locket", radius: 0.08, height: 0.02, color: i.gold, at: [-0.3, 0.83, -1.55] },
    { type: "light", color: 16767370, intensity: 1.1, distance: 3, at: [-0.3, 1.2, -1.4] }
  ], y = [
    { type: "text", text: t.act3.title, size: [1.2, 0.8], color: "#7a2a3a", at: [0, 1.9, -3.38] },
    { type: "box", size: [1.6, 0.4, 0.5], color: 6971480, at: [0, 0.2, -1.4], solid: !0 },
    { type: "box", size: [0.25, 2.2, 0.25], color: 3811866, at: [-2.2, 1.1, -2.4], solid: !0 },
    { type: "ico", radius: 0.7, color: 15245488, at: [-2.2, 2.4, -2.4] },
    { type: "box", size: [0.25, 2, 0.25], color: 3811866, at: [2.3, 1, -2], solid: !0 },
    { type: "ico", radius: 0.6, color: 15775940, at: [2.3, 2.1, -2] },
    { type: "box", size: [2.4, 0.02, 0.6], color: 3824234, at: [-1.6, 0.01, 0.6] },
    { type: "candle", at: [0.6, 0.4, -1.5], intensity: 2.2 },
    { type: "box", id: "book", size: [0.3, 0.05, 0.22], color: 14207144, at: [-0.2, 0.43, -1.4] }
  ], d = [
    { type: "text", text: t.act4.title, size: [1.4, 0.45], color: "#7a2a3a", at: [0, 2.75, -3.38] },
    { type: "ico", radius: 0.45, color: 4863526, at: [0, 0.15, -1.6] },
    { type: "box", size: [0.04, 1.1, 0.04], color: 5914672, at: [0.7, 0.55, -1.5] },
    { type: "box", size: [0.25, 0.06, 0.04], color: 8026746, at: [0.7, 1.1, -1.5] },
    { type: "candle", at: [-1.2, 0, -1.9], intensity: 1.6 },
    { type: "box", id: "pouch", size: [0.22, 0.14, 0.16], color: 12601962, at: [-0.25, 0.62, -1.45] },
    { type: "light", color: 16756928, intensity: 1, distance: 3, at: [-0.25, 1, -1.3] }
  ], n = 0; n < 9; n++) d.push({ type: "box", size: [0.08, 0.01, 0.08], color: 15771832, at: [-1.6 + n * 0.4, 0.01, -0.6 + n % 2 * 0.5] });
  function h(a) {
    var e = a.route === "jinyu";
    return { wall: e ? 1842724 : 3022872, floor: 1446414, w: 8, d: 8, fog: e ? 329740 : 657414, ambient: e ? 2502714 : 3811872, ambientIntensity: e ? 0.6 : 0.8, spawn: [0, 3] };
  }
  function f(a) {
    for (var e = a.route === "jinyu", o = e ? 1.2 : 2, c = [
      { type: "text", text: t.act5.title, size: [1.2, 0.8], color: e ? "#2a3a4a" : "#4A0E1F", at: [0, 1.9, -3.88] },
      { type: "candle", at: [-1.6, 0, -2.8], intensity: o },
      { type: "candle", at: [1.6, 0, -2.8], intensity: o * 0.8 },
      { type: "box", id: "chest", size: [0.9, 0.5, 0.5], color: 5909018, at: [0, 0.25, -1.8], solid: !0 },
      { type: "light", color: 16763024, intensity: 0.9, distance: 3, at: [0, 1, -1.5] }
    ], r = 0; r < 4; r++) c.push({ type: "box", size: [0.6, 0.4, 0.4], color: 3809812, at: [-2.6 + r % 2 * 0.7, 0.2 + (r > 1 ? 0.4 : 0), 1.6], solid: r < 2 });
    return c;
  }
  function g(a) {
    var e = !!a.frost, o = a.route === "jinyu" || e;
    return { wall: i.bamboo, floor: 1317394, w: 7, d: 7, fog: o ? 329482 : 526602, ambient: o ? 2107946 : 3027494, ambientIntensity: e ? 0.45 : 0.7, spawn: [0, 2.5] };
  }
  function z(a) {
    for (var e = (a.frost ? 0.9 : 1.6) * (a.route === "jinyu" ? 0.8 : 1), o = [
      { type: "text", text: t.act6.title, size: [1.2, 0.8], color: "#2f4a2a", at: [0, 1.9, -3.38] },
      { type: "box", size: [1.4, 0.08, 0.7], color: 3811866, at: [-0.8, 0.78, -1.6], solid: !0 },
      { type: "candle", at: [-1.2, 0.82, -1.7], intensity: e },
      { type: "cylinder", radius: 0.28, height: 0.3, color: 2763306, at: [0.9, 0.15, -1.4] },
      { type: "light", color: 16742970, intensity: 1.6, distance: 2.5, at: [0.9, 0.5, -1.4] },
      { type: "box", id: "drafts", size: [0.3, 0.06, 0.4], color: i.parch, at: [-0.6, 0.85, -1.55] }
    ], c = 0; c < 5; c++) o.push({ type: "box", size: [0.08, 3, 0.08], color: 4086326, at: [-3 + c * 0.15, 1.5, -3.1 + c % 2 * 0.3] });
    return o;
  }
  for (var p = [
    { type: "text", text: t.act7.title, size: [1.2, 0.8], color: "#3a3a4a", bg: "#e8ecf0", at: [0, 1.9, -3.88] },
    { type: "box", size: [0.3, 2.2, 0.3], color: 2763312, at: [-2.4, 1.1, -2.6], solid: !0 },
    { type: "box", size: [0.3, 2.2, 0.3], color: 2763312, at: [2.4, 1.1, -2.6], solid: !0 },
    { type: "box", size: [5.4, 0.3, 0.4], color: 2763312, at: [0, 2.35, -2.6] },
    { type: "light", color: 13161704, intensity: 1.4, distance: 8, at: [0, 2.6, 0] },
    { type: "box", id: "cloak", size: [0.5, 0.08, 0.4], color: 10492452, at: [0, 0.04, -1.4] },
    { type: "light", color: 16751264, intensity: 0.9, distance: 2.5, at: [0, 0.6, -1.2] }
  ], s = 0; s < 12; s++) p.push({ type: "box", size: [0.04, 0.04, 0.04], color: 16777215, at: [-2.5 + s * 7 % 11 * 0.45, 0.5 + s * 5 % 7 * 0.35, -2 + s * 3 % 5 * 0.7] });
  function l(a, e, o, c) {
    return { text: a, record: e, keyChoice: !0, versionBit: o, next: c };
  }
  var x = [
    {
      id: "rongguo",
      hud: t.act1.hud,
      fade: t.act1.fade,
      room: { wall: i.red, floor: 1970186, w: 7, d: 7, spawn: [0, 2.5] },
      props: u,
      interaction: {
        type: "choice",
        target: "jade",
        label: t.act1.label,
        title: t.act1.title,
        sub: t.act1.sub,
        text: t.act1.text,
        options: [l(t.act1.choices[0], t.act1.choices[0], 0), l(t.act1.choices[1], t.act1.choices[1], 1)]
      }
    },
    {
      id: "flower-tomb",
      hud: t.act4.hud,
      fade: t.act4.fade,
      room: { wall: 2759200, floor: 1708560, w: 7, d: 7, fog: 722440, spawn: [0, 2.5] },
      props: d,
      interaction: {
        type: "choice",
        target: "pouch",
        label: t.act4.label,
        title: t.act4.title,
        sub: t.act4.sub,
        text: t.act4.text,
        options: [l(t.act4.choices[0], t.act4.choices[0], 0), l(t.act4.choices[1], t.act4.choices[1], 1)]
      }
    },
    {
      id: "snow",
      hud: t.act7.hud,
      fade: t.act7.fade,
      room: { wall: 13620958, floor: 15001838, ceiling: 1711654, w: 8, d: 8, fog: 1711654, ambient: 9082538, ambientIntensity: 0.7, spawn: [0, 3] },
      props: p,
      interaction: {
        type: "dead-letter",
        target: "cloak",
        label: t.act7.label,
        title: t.act7.title,
        sub: t.act7.sub,
        text: t.act7.text,
        options: [l(t.act7.choices[0], t.act7.choices[0], 0, "catalog"), l(t.act7.choices[1], t.act7.choices[1], 1, "catalog")]
      }
    }
  ], w = [
    x[0],
    {
      id: "lixiang",
      hud: t.act2.hud,
      fade: t.act2.fade,
      room: { wall: 3811866, floor: 2234382, w: 7, d: 7, spawn: [0, 2.5] },
      props: b,
      interaction: {
        type: "choice",
        target: "locket",
        label: t.act2.label,
        title: t.act2.title,
        sub: t.act2.sub,
        text: t.act2.text,
        options: [{ text: t.act2.choices[0], route: "jinyu" }, { text: t.act2.choices[1], route: "mushi" }]
      }
    },
    {
      id: "garden",
      hud: t.act3.hud,
      fade: t.act3.fade,
      room: { wall: 2767402, floor: 1976858, w: 7, d: 7, fog: 659466, spawn: [0, 2.5] },
      props: y,
      interaction: {
        type: "choice",
        target: "book",
        label: t.act3.label,
        title: t.act3.title,
        sub: t.act3.sub,
        text: t.act3.text,
        options: [{ text: t.act3.choices[0] }, { text: t.act3.choices[1] }]
      }
    },
    x[1],
    {
      id: "search",
      hud: t.act5.hud,
      fade: t.act5.fade,
      room: h,
      props: f,
      interaction: {
        type: "choice",
        target: "chest",
        label: t.act5.label,
        title: t.act5.title,
        sub: t.act5.sub,
        text: t.act5.text,
        options: [{ text: t.act5.choices[0], set: { frost: "" } }, { text: t.act5.choices[1], set: { frost: "深" } }]
      }
    },
    {
      id: "xiaoxiang",
      hud: t.act6.hud,
      fade: t.act6.fade,
      room: g,
      props: z,
      interaction: {
        type: "choice",
        target: "drafts",
        label: t.act6.label,
        title: t.act6.title,
        sub: t.act6.sub,
        text: t.act6.text,
        options: [{ text: t.act6.choices[0], set: { draft: "焚" } }, { text: t.act6.choices[1], set: { draft: "留" } }]
      }
    },
    x[2]
  ];
  window.__STORY__ = {
    title: t.title,
    pageTitle: t.pageTitle,
    copy: t,
    palette: { ink: 5905946, candle: 16754784 },
    start: { title: t.title, sub: t.startSub, html: '<p class="hook">' + t.hook + "</p>", button: t.startButton },
    acts: x,
    fullActs: w,
    catalog: { title: t.resultTitle, restartFade: t.act1.fade }
  };
})();
