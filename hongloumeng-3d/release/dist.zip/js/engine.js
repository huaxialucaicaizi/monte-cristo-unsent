window.__BOOT_GAME__ = function() {
  "use strict";
  var f = window.__STORY__, s = function(t) {
    return document.getElementById(t);
  };
  if (!f || !f.acts || !f.acts.length) {
    s("st-body").innerHTML = "<p>剧本缺少 acts。</p>";
    return;
  }
  function ut(t, e) {
    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t;
  }
  var L = ut({ parch: 16051423, ink: 4853279, candle: 16756838, flame: 16765066, ceiling: 1182214, ambient: 3811872, fog: 722436 }, f.palette || {}), U = ut({ hint: " · 按 E / 点击查看", copy: "复制全文", copied: "已复制", restart: "重新开始", catalogTitle: "你的版本目录", sealGlyph: "✠" }, f.ui || {}), y = f.acts;
  function Q() {
    return { act: 0, choices: [], keyChoices: [], versionBits: [], route: "", ending: "", fullVersion: !1 };
  }
  var c = Q(), I = new THREE.WebGLRenderer({ antialias: window.devicePixelRatio < 2 });
  I.setPixelRatio(Math.min(window.devicePixelRatio, 1.5)), I.setSize(innerWidth, innerHeight), document.body.insertBefore(I.domElement, document.body.firstChild);
  var Y = new THREE.Scene(), M = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.05, 60), H = 0, P = 0, p = new THREE.Vector3(0, 1.6, 3), V = [], S = [], W = [], v = null, tt = 4.5, et = null, _ = s("panel"), nt = s("hint"), it = s("hud"), ot = s("fade"), m = !0, E = {}, C = null;
  function u(t) {
    return t == null ? "" : typeof t == "function" ? String(t(c)) : String(t).replace(/\{(\w+)(?:=([^?{}]*)\?([^:{}]*):([^{}]*))?\}/g, function(e, n, i, r, o) {
      var a = /^choice(\d+)$/.exec(n), l = a ? c.choices[+a[1]] : c[n];
      return i !== void 0 ? String(l == null ? "" : l) === i ? r : o : l == null ? "" : l;
    });
  }
  function ft(t) {
    return typeof t == "function" ? t(c) : t;
  }
  function R() {
    return !!f.darkRoute && c.route === f.darkRoute;
  }
  function A(t, e) {
    return e = e || {}, e.color = t, e.roughness = e.roughness == null ? 0.85 : e.roughness, new THREE.MeshStandardMaterial(e);
  }
  function w(t, e) {
    return t.position.set(e[0], e[1], e[2]), v.add(t), t;
  }
  function G(t, e, n, i, r, o, a, l) {
    var d = w(new THREE.Mesh(new THREE.BoxGeometry(t, e, n), A(i)), [r, o, a]);
    return l && V.push({ minX: r - t / 2 - 0.25, maxX: r + t / 2 + 0.25, minZ: a - n / 2 - 0.25, maxZ: a + n / 2 + 0.25 }), d;
  }
  function kt(t, e, n, i) {
    var r = i || 2.2;
    G(0.06, 0.18, 0.06, L.parch, t, e + 0.09, n);
    var o = w(new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 6), new THREE.MeshBasicMaterial({ color: L.flame })), [t, e + 0.22, n]), a = w(new THREE.PointLight(L.candle, r, 7, 1.6), [t, e + 0.35, n]);
    W.push({ l: a, f: o, b: r });
  }
  function dt(t, e, n, i, r) {
    var o = document.createElement("canvas");
    o.width = 512, o.height = Math.round(512 * n / e);
    var a = o.getContext("2d");
    a.fillStyle = r || "#F4ECDF", a.fillRect(0, 0, o.width, o.height), a.fillStyle = i || "#2B1810", a.font = "bold " + Math.round(o.height * 0.16) + "px serif", a.textAlign = "center", a.textBaseline = "middle", t.split(`
`).forEach(function(d, h, z) {
      a.fillText(d, 256, o.height / 2 + (h - (z.length - 1) / 2) * o.height * 0.22);
    });
    var l = new THREE.CanvasTexture(o);
    return new THREE.Mesh(new THREE.PlaneGeometry(e, n), new THREE.MeshStandardMaterial({ map: l, roughness: 0.9 }));
  }
  function Ht(t) {
    v && Y.remove(v), v = new THREE.Group(), Y.add(v), V = [], S = [], W = [], et = t;
    var e = t.w || 8, n = t.d || 8, i = t.fog || L.fog;
    tt = e / 2 - 0.35, Y.fog = new THREE.Fog(i, 3, 13), Y.background = new THREE.Color(i);
    var r = new THREE.Mesh(new THREE.PlaneGeometry(e, n), A(t.floor));
    r.rotation.x = -Math.PI / 2, v.add(r);
    var o = new THREE.Mesh(new THREE.PlaneGeometry(e, n), A(t.ceiling || L.ceiling));
    o.rotation.x = Math.PI / 2, o.position.y = 3.2, v.add(o), G(e, 3.2, 0.2, t.wall, 0, 1.6, -n / 2), G(e, 3.2, 0.2, t.wall, 0, 1.6, n / 2), G(0.2, 3.2, n, t.wall, -e / 2, 1.6, 0), G(0.2, 3.2, n, t.wall, e / 2, 1.6, 0), v.add(new THREE.AmbientLight(t.ambient || L.ambient, t.ambientIntensity == null ? 0.9 : t.ambientIntensity));
  }
  function St(t) {
    var e = t.at || [0, 0, 0], n = t.size || [1, 1, 1], i = null;
    switch (t.type) {
      case "box":
        i = G(n[0], n[1], n[2], t.color, e[0], e[1], e[2], t.solid);
        break;
      case "candle":
        kt(e[0], e[1], e[2], t.intensity);
        break;
      case "text":
        i = w(dt(t.text, n[0], n[1], t.color, t.bg), e), t.rotZ && (i.rotation.z = t.rotZ);
        break;
      case "plane":
        i = w(new THREE.Mesh(new THREE.PlaneGeometry(n[0], n[1]), t.unlit ? new THREE.MeshBasicMaterial({ color: t.color }) : A(t.color)), e);
        break;
      case "cylinder":
        i = w(new THREE.Mesh(new THREE.CylinderGeometry(t.radius, t.radius, t.height, t.segments || 12), A(t.color)), e);
        break;
      case "ico":
        i = w(new THREE.Mesh(new THREE.IcosahedronGeometry(t.radius, 0), A(t.color, { metalness: t.metalness || 0, roughness: t.roughness })), e);
        break;
      case "spot":
        var r = w(new THREE.SpotLight(t.color, t.intensity, t.distance, t.angle, t.penumbra, t.decay), e), o = t.target || [0, 0, 0];
        r.target.position.set(o[0], o[1], o[2]), v.add(r.target), i = r;
        break;
      case "light":
        i = w(new THREE.PointLight(t.color, t.intensity, t.distance || 7, t.decay || 1.6), e);
        break;
      default:
        console.warn("未知 prop 类型", t.type);
    }
    return i;
  }
  function ht(t, e, n) {
    t.userData = { label: e, fn: n }, S.push(t);
    var i = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), new THREE.MeshBasicMaterial({ color: 16769704 }));
    i.position.copy(t.position), i.position.y += 0.35, v.add(i), t.userData.glow = i;
  }
  function T(t, e) {
    _.innerHTML = t, _.style.display = "block", _.classList.toggle("dark", !!e), m = !0, document.exitPointerLock && document.exitPointerLock();
  }
  function rt() {
    _.style.display = "none", m = !1;
  }
  function b(t, e) {
    return "<h2>" + u(t) + "</h2>" + (e ? '<div class="sub">' + u(e) + "</div>" : "");
  }
  function B(t) {
    return t.map(function(e, n) {
      return '<button class="opt" data-i="' + n + '">' + u(typeof e == "string" ? e : e.text) + "</button>";
    }).join("");
  }
  function O(t) {
    [].forEach.call(_.querySelectorAll(".opt"), function(e) {
      e.onclick = function() {
        t(+e.dataset.i);
      };
    });
  }
  function at(t, e) {
    m = !0, ot.textContent = t, ot.classList.add("on"), setTimeout(function() {
      e(), setTimeout(function() {
        ot.classList.remove("on"), m = !1;
      }, 500);
    }, 900);
  }
  function pt(t, e) {
    return '<div class="seal" id="sl">' + (t.glyph || U.sealGlyph) + "</div>" + (e != null ? '<p id="sm" style="text-align:center;font-size:13px">' + u(e) + "</p>" : "");
  }
  function _t(t) {
    for (var e = 0; e < y.length; e++) if (y[e].id === t) return e;
    return -1;
  }
  function Z(t) {
    var e = y[t];
    c.act = t + 1, c.actId = e.id, it.textContent = u(e.hud);
    var n = ft(e.room) || {};
    Ht(n);
    var i = n.spawn || [0, 3];
    p.set(i[0], 1.6, i[1]), H = n.yaw || 0, P = 0, C = null;
    var r = {};
    (ft(e.props) || []).forEach(function(o) {
      var a = St(o);
      o.id && a && (r[o.id] = a);
    }), (e.interactions || (e.interaction ? [e.interaction] : [])).forEach(function(o) {
      var a = r[o.target];
      if (!a) {
        console.warn("交互 target 不存在：", o.target);
        return;
      }
      var l = Gt[o.type];
      if (!l) {
        console.warn("未知交互类型：", o.type);
        return;
      }
      ht(a, u(o.label), function() {
        l(o, { mesh: a, props: r });
      });
    });
  }
  function D(t) {
    if (rt(), t === "catalog") {
      gt();
      return;
    }
    var e = t ? _t(t) : c.act;
    if (t && e < 0 && console.warn("找不到幕：", t), e < 0 || e >= y.length) {
      gt();
      return;
    }
    at(u(y[e].fade || y[e].hud), function() {
      Z(e);
    });
  }
  function lt(t, e) {
    t.record != null && c.choices.push(u(t.record));
    var n = t.keyChoice || c.actId === "rongguo" || c.actId === "flower-tomb" || c.actId === "snow";
    if (n && c.keyChoices.length < 3 && (c.keyChoices.push(u(t.record != null ? t.record : t.text)), c.versionBits.push(t.versionBit == null ? (e.optionIndex || 0) % 2 : t.versionBit)), t.route !== void 0 && (c.route = t.route), t.set) for (var i in t.set) c[i] = u(t.set[i]);
    t.ending != null && (c.ending = u(t.ending));
    var r = t.next || e.next;
    if (t.toggle) return Ct(t.toggle, r);
    if (t.wall) return Lt(t.wall, r);
    if (t.lock) return It(t.lock, e, r);
    D(r);
  }
  function Ct(t, e) {
    var n = 0, i = t.readings;
    (function r() {
      var o = i[n];
      T(b(o.title) + "<p>" + u(o.text) + '</p><button class="toggle" id="tg">' + u(t.button || "切换读法") + "</button>" + B([t.proceed || "继续"]), o.dark == null ? R() : o.dark), s("tg").onclick = function() {
        n = (n + 1) % i.length, r();
      }, O(function() {
        D(e);
      });
    })();
  }
  function Lt(t, e) {
    rt();
    var n = t.words, i = n.length, r = et && et.d || 8, o = t.z != null ? t.z : -r / 2 + 0.12, a = function(l, d) {
      return String(l).replace(/\{(\w)\}/g, function(h, z) {
        return d[z];
      });
    };
    n.forEach(function(l, d) {
      var h = dt(l, 0.6, 0.4, t.color || "#4A0E1F");
      h.position.set(-(n.length - 1) / 2 + d, 1.7 + d % 2 * 0.4, o), h.rotation.z = d % 2 ? 0.06 : -0.05, v.add(h), ht(h, a(t.label || "划掉「{w}」", { w: l }), function() {
        h.material.color.set(9075306), h.scale.y = 0.25, S.splice(S.indexOf(h), 1), v.remove(h.userData.glow), i--, it.textContent = a(t.hudLeft || "还剩 {n} 个词", { n: i }), i || (T(b(t.doneTitle) + "<p>" + u(t.doneText) + "</p>" + B([t.doneOption || "继续"]), R()), O(function() {
          D(e);
        }));
      });
    }), it.textContent = a(t.hudStart || "点掉墙上 {n} 个词", { n: i });
  }
  function It(t, e, n) {
    var i = 0, r = t.clicks || 2;
    T(b(t.title, t.sub) + pt(t), R()), s("sl").onclick = function() {
      if (++i < r) {
        this.style.transform = "scale(.9)";
        return;
      }
      var o = t.push;
      o && e.mesh && (e.mesh.position.x += o[0] || 0, e.mesh.position.y += o[1] || 0, e.mesh.position.z += o[2] || 0), D(n || "catalog");
    };
  }
  function Pt(t, e) {
    var n = 0, i = t.clicks || 3, r = e.props[t.seal];
    T(b(t.title, t.sub) + pt(t, t.firstMsg || ""), R()), s("sl").onclick = function() {
      if (n++, this.style.transform = "rotate(" + n * 25 + "deg)", this.style.opacity = 1 - n / (i + 1), r && r.scale.setScalar(Math.max(0.05, 1 - n * 0.9 / i)), n < i) {
        s("sm").textContent = u((t.crackMsgs || [])[n - 1] || "");
        return;
      }
      r && v.remove(r), T(b(t.title) + u(t.text) + B(t.options), R()), O(function(o) {
        e.optionIndex = o, lt(t.options[o], e);
      });
    };
  }
  function At(t, e) {
    var n = t.pains;
    T(b(t.title, t.sub) + u(t.intro) + B(n), R()), O(function(i) {
      if (c[t.painKey || "pain"] = u(n[i]), !t.options || !t.options.length) return D(t.next);
      T(b(t.title) + u(t.after) + B(t.options), R()), O(function(r) {
        lt(t.options[r], e);
      });
    });
  }
  function j(t, e) {
    T(b(t.title, t.sub) + u(t.text) + B(t.options), R()), O(function(n) {
      e.optionIndex = n, lt(t.options[n], e);
    });
  }
  var Gt = {
    "letter-seal": Pt,
    diary: At,
    choice: j,
    map: j,
    name: j,
    gazette: j,
    "dead-letter": function(t, e) {
      e.next = t.next || "catalog", j(t, e);
    }
  };
  function Bt() {
    for (var t = 0, e = 0; e < 3; e++) t = t * 2 + (c.versionBits[e] || 0);
    return t;
  }
  function st(t, e, n, i, r, o) {
    for (var a = String(e).split(""), l = "", d = 0; d < a.length; d++) {
      var h = l + a[d];
      t.measureText(h).width > r && l ? (t.fillText(l, n, i), l = a[d], i += o) : l = h;
    }
    return l && t.fillText(l, n, i), i;
  }
  function vt() {
    var t = f.copy || {}, e = document.createElement("canvas");
    e.width = 1080, e.height = 1440;
    var n = e.getContext("2d"), i = n.createLinearGradient(0, 0, 1080, 1440);
    i.addColorStop(0, "#f4ead9"), i.addColorStop(0.58, "#dcc3aa"), i.addColorStop(1, "#8c2f34"), n.fillStyle = i, n.fillRect(0, 0, 1080, 1440), n.strokeStyle = "rgba(74,14,31,.42)", n.lineWidth = 3, n.strokeRect(58, 58, 964, 1324), n.textAlign = "center", n.fillStyle = "#4a0e1f", n.font = "54px serif", n.fillText(t.title || f.title, 540, 155), n.font = "30px serif", n.fillStyle = "#75564b", n.fillText(t.resultTitle || "你的版本", 540, 235);
    var r = (t.versionTitles || [])[Bt()] || f.title;
    n.font = "bold 74px serif", n.fillStyle = "#4a0e1f", st(n, r, 540, 345, 870, 88), n.textAlign = "left", n.font = "32px serif", n.fillStyle = "#4b3028";
    for (var o = t.cardLabels || [], a = c.keyChoices, l = 0; l < 3; l++) {
      var d = 550 + l * 170;
      n.fillStyle = "#8c2f34", n.font = "26px serif", n.fillText("0" + (l + 1) + "  " + (o[l] || ""), 120, d), n.fillStyle = "#37231f", n.font = "34px serif", st(n, a[l] || "—", 120, d + 58, 840, 46);
    }
    return n.textAlign = "center", n.fillStyle = "#4a0e1f", n.font = "italic 34px serif", st(n, t.quote || "", 540, 1120, 820, 50), n.font = "24px serif", n.fillStyle = "#6e5147", n.fillText(t.attribution || "", 540, 1280), n.textAlign = "right", n.font = "24px sans-serif", n.fillText(t.author || "", 960, 1350), { canvas: e, dataUrl: e.toDataURL("image/png"), title: r };
  }
  function gt() {
    var t = f.catalog || {}, e = f.copy || {}, n = vt();
    T('<div class="result-panel">' + b(e.resultTitle || t.title || U.catalogTitle) + '<img id="result-card" class="result-card" alt="红楼梦结局卡"><div class="result-actions"><button class="opt primary" id="post-note">' + (e.shareButton || "发布") + '</button><button class="opt" id="restart">' + (e.restartButton || U.restart) + '</button></div><div class="status" id="share-status"></div></div>', !1), _.classList.add("result-panel"), s("result-card").src = n.dataUrl, window.__MINITOOL__ && window.__MINITOOL__.saveResult({ title: n.title, choices: c.keyChoices }), s("post-note").onclick = function() {
      var i = window.xhs && window.xhs.miniTool, r = s("share-status");
      if (!i || typeof i.postNote != "function") {
        r.textContent = e.shareUnavailable || "";
        return;
      }
      this.disabled = !0, r.textContent = "";
      var o = String(e.noteBody || "").replace("{title}", n.title);
      i.postNote({
        title: e.noteTitle || n.title,
        content: o,
        pageType: "photo_publish",
        mediaInfo: { image_resources: [{ url: n.dataUrl }] }
      }).catch(function() {
        r.textContent = e.shareFailed || "";
      }).then(function() {
        s("post-note").disabled = !1;
      });
    }, s("restart").onclick = function() {
      _.classList.remove("result-panel"), y = f.acts, c = Q(), window.__GAME__.state = c, rt(), at(u(t.restartFade || y[0].fade || ""), function() {
        Z(0);
      });
    };
  }
  var F = I.domElement, yt = new THREE.Raycaster(), X = null;
  addEventListener("keydown", function(t) {
    E[t.code] = 1, t.code === "KeyE" && X && !m && X.userData.fn();
  }), addEventListener("keyup", function(t) {
    E[t.code] = 0;
  });
  var g = null, K = !1;
  document.addEventListener("pointerlockchange", function() {
    K = document.pointerLockElement === F;
  }), document.addEventListener("mousemove", function(t) {
    K && (H -= t.movementX * 25e-4, P = Et(P - t.movementY * 25e-4));
  });
  function Et(t) {
    return Math.max(-1.2, Math.min(1.2, t));
  }
  var ct = "ontouchstart" in window;
  ct && (s("joy").style.display = "block"), F.addEventListener("pointerdown", function(t) {
    g = { id: t.pointerId, x: t.clientX, y: t.clientY, sx: t.clientX, sy: t.clientY, t: Date.now() };
  }), F.addEventListener("pointermove", function(t) {
    !g || g.id !== t.pointerId || K || (H -= (t.clientX - g.x) * 5e-3, P = Et(P - (t.clientY - g.y) * 5e-3), g.x = t.clientX, g.y = t.clientY);
  }), F.addEventListener("pointerup", function(t) {
    if (g) {
      var e = Math.abs(t.clientX - g.sx) + Math.abs(t.clientY - g.sy) < 10 && Date.now() - g.t < 400;
      if (g = null, !(!e || m)) {
        var n = K ? new THREE.Vector2(0, 0) : new THREE.Vector2(t.clientX / innerWidth * 2 - 1, -(t.clientY / innerHeight) * 2 + 1);
        yt.setFromCamera(n, M);
        var i = yt.intersectObjects(S)[0];
        if (i)
          i.object.position.distanceTo(M.position) < 2.4 ? i.object.userData.fn() : C = i.object;
        else if (!ct && !K && F.requestPointerLock)
          try {
            F.requestPointerLock();
          } catch (r) {
          }
      }
    }
  });
  var x = { x: 0, y: 0, id: null }, N = s("joy"), q = s("knob");
  N.addEventListener("pointerdown", function(t) {
    x.id = t.pointerId, N.setPointerCapture(t.pointerId), mt(t);
  }), N.addEventListener("pointermove", function(t) {
    x.id === t.pointerId && mt(t);
  }), N.addEventListener("pointerup", function() {
    x.id = null, x.x = x.y = 0, q.style.left = q.style.top = "35px";
  });
  function mt(t) {
    var e = N.getBoundingClientRect(), n = t.clientX - e.left - 55, i = t.clientY - e.top - 55, r = Math.min(45, Math.hypot(n, i)) / (Math.hypot(n, i) || 1);
    n *= r, i *= r, q.style.left = 35 + n + "px", q.style.top = 35 + i + "px", x.x = n / 45, x.y = i / 45;
  }
  addEventListener("resize", function() {
    M.aspect = innerWidth / innerHeight, M.updateProjectionMatrix(), I.setSize(innerWidth, innerHeight);
  });
  function wt(t, e) {
    var n = p.x + t, i = p.z + e;
    function r(o, a) {
      if (Math.abs(o) > tt || Math.abs(a) > tt) return !0;
      for (var l = 0; l < V.length; l++) {
        var d = V[l];
        if (o > d.minX && o < d.maxX && a > d.minZ && a < d.maxZ) return !0;
      }
      return !1;
    }
    r(n, p.z) || (p.x = n), r(p.x, i) || (p.z = i);
  }
  var Tt = new THREE.Clock();
  function bt() {
    requestAnimationFrame(bt);
    var t = Math.min(Tt.getDelta(), 0.05), e = Tt.elapsedTime;
    if (!m) {
      var n = (E.KeyW || E.ArrowUp ? 1 : 0) - (E.KeyS || E.ArrowDown ? 1 : 0) - x.y, i = (E.KeyD || E.ArrowRight ? 1 : 0) - (E.KeyA || E.ArrowLeft ? 1 : 0) + x.x;
      if (C) {
        var r = C.position.x - p.x, o = C.position.z - p.z, a = Math.hypot(r, o);
        if (a < 1.3 || n || i)
          C = null;
        else {
          H = Math.atan2(-r, -o);
          var l = p.x, d = p.z;
          wt(r / a * 2 * t, o / a * 2 * t), l === p.x && d === p.z && (C = null);
        }
      }
      var h = 2.2 * t, z = Math.sin(H), Mt = Math.cos(H);
      (n || i) && wt((-z * n + Mt * i) * h, (-Mt * n - z * i) * h);
    }
    M.position.copy(p), M.rotation.set(P, H, 0, "YXZ"), W.forEach(function(k, J) {
      k.l.intensity = k.b * (0.85 + 0.15 * Math.sin(e * 9 + J) + 0.05 * Math.sin(e * 23));
    }), X = null;
    var Rt = 2.4;
    S.forEach(function(k) {
      var J = k.position.distanceTo(M.position);
      k.userData.glow && (k.userData.glow.position.y = k.position.y + 0.35 + 0.04 * Math.sin(e * 3)), J < Rt && (Rt = J, X = k);
    }), X && !m ? (nt.style.display = "block", nt.textContent = X.userData.label + U.hint) : nt.style.display = "none", I.render(Y, M);
  }
  var $ = f.start || {};
  document.title = f.pageTitle || f.title || document.title, s("st-title").innerHTML = u($.title || f.title), s("st-sub").innerHTML = u($.sub || f.subtitle || ""), s("st-body").innerHTML = u($.html || ""), s("go").textContent = u($.button || "— 开始 —"), s("go").hidden = !1;
  function xt() {
    s("start").style.display = "none", at(u(y[0].fade || ""), function() {
      Z(0), ct && window.__MINITOOL__ && window.__MINITOOL__.showGestureOnce();
    });
  }
  s("go").onclick = xt, s("full-entry").textContent = u(f.copy && f.copy.fullEntry || "完整版"), s("full-entry").onclick = function() {
    y = f.fullActs || f.acts, c = Q(), c.fullVersion = !0, window.__GAME__.state = c, xt();
  }, Z(0), m = !0, bt(), window.__GAME__ = {
    state: c,
    story: f,
    go: D,
    hotspots: function() {
      return S.slice();
    },
    revealFullVersion: function() {
      s("full-entry").hidden = !1;
    },
    startFullVersion: function() {
      s("full-entry").hidden = !1, s("full-entry").click();
    },
    resultCard: function() {
      return vt();
    }
  };
};
