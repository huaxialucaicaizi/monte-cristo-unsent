(function() {
  "use strict";
  var l = 9460, o = "red-chamber:";
  function f(t) {
    var e = t && t.miniToolEnv;
    return Number(e && e.buildVersion) || 0;
  }
  function d(t) {
    return Math.floor(t / 1e3);
  }
  function h() {
    var t = window.xhs, e = f(t && t.launchOptions);
    if (e) return Promise.resolve(e);
    var n = t && t.miniTool;
    return !n || typeof n.getLaunchOptions != "function" ? Promise.resolve(0) : n.getLaunchOptions().then(f).catch(function() {
      return 0;
    });
  }
  function g(t) {
    try {
      var e = localStorage.getItem(o + t);
      return e === null ? null : JSON.parse(e);
    } catch (n) {
      return null;
    }
  }
  function v(t, e) {
    try {
      return localStorage.setItem(o + t, JSON.stringify(e)), !0;
    } catch (n) {
      return !1;
    }
  }
  function m(t) {
    return h().then(function(e) {
      var n = window.xhs && window.xhs.miniTool;
      return d(e) >= l && n && typeof n.getStorage == "function" ? n.getStorage({ key: o + t }).then(function(r) {
        if (!r || r.data === null) return null;
        try {
          return JSON.parse(r.data);
        } catch (u) {
          return null;
        }
      }).catch(function() {
        return null;
      }) : g(t);
    });
  }
  function c(t, e) {
    var n;
    try {
      n = JSON.stringify(e);
    } catch (r) {
      return Promise.resolve(!1);
    }
    return typeof n != "string" ? Promise.resolve(!1) : h().then(function(r) {
      var u = window.xhs && window.xhs.miniTool;
      return d(r) >= l && u && typeof u.setStorage == "function" ? u.setStorage({ key: o + t, data: n }).then(function() {
        return !0;
      }).catch(function() {
        return !1;
      }) : v(t, e);
    });
  }
  function y() {
    m("joystick-guide").then(function(t) {
      if (!t) {
        var e = document.getElementById("joy-guide");
        e.classList.add("on"), setTimeout(function() {
          e.classList.remove("on");
        }, 1e3), c("joystick-guide", { shown: !0 });
      }
    });
  }
  function w(t) {
    c("last-result", { title: t.title, choices: t.choices.slice(0, 3) });
  }
  window.__MINITOOL__ = { getLocalData: m, setLocalData: c, showGestureOnce: y, saveResult: w };
  var a = document.getElementById("st-title"), i = 0;
  function s() {
    i && (clearTimeout(i), i = 0);
  }
  a.addEventListener("pointerdown", function() {
    s(), i = setTimeout(function() {
      i = 0;
      var t = document.getElementById("full-entry");
      t.hidden = !1;
    }, 1200);
  }), a.addEventListener("pointerup", s), a.addEventListener("pointercancel", s), typeof window.__BOOT_GAME__ == "function" ? window.__BOOT_GAME__() : document.getElementById("st-title").textContent = "载入失败";
})();
